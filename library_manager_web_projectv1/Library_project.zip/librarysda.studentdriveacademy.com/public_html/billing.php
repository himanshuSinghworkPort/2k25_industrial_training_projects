<?php
session_start();
require_once "db_connect.php";

// Security check
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION['role'] !== 'user'){
    header("location: index.php");
    exit;
}

$user_id = $_SESSION['id'];

// Get user info for the sidebar
$sidebar_user_stmt = $conn->prepare("SELECT username, avatar_path FROM users WHERE id = ?");
$sidebar_user_stmt->bind_param("i", $user_id);
$sidebar_user_stmt->execute();
$sidebar_user_result = $sidebar_user_stmt->get_result();
$sidebar_user = $sidebar_user_result->fetch_assoc();
$sidebar_user_stmt->close();

// Fetch payment slips for the logged-in user
$payment_slips_sql = "SELECT * FROM payments WHERE user_id = ? ORDER BY generated_at DESC";
$stmt = $conn->prepare($payment_slips_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$payment_slips_result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Billing - SV Library System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <aside class="w-64 bg-gray-800 text-white min-h-screen p-4 flex flex-col justify-between">
        <div>
            <div class="flex items-center justify-center mb-10">
                 <svg class="w-8 h-8 mr-2 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"></path></svg>
                <h2 class="text-2xl font-bold">SV Library</h2>
            </div>
            <nav>
                <a href="user_dashboard.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 hover:text-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h12a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V6z"></path></svg>
                    Book a Seat
                </a>
                <a href="profile.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 hover:text-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                    My Profile
                </a>
                <a href="billing.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 bg-gray-700 text-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path></svg>
                    My Billing
                </a>
            </nav>
        </div>
        <div>
            <div class="border-t border-gray-700 mb-4"></div>
            <a href="profile.php" class="flex items-center p-2 rounded transition duration-200 hover:bg-gray-700">
                <img src="<?php echo htmlspecialchars($sidebar_user['avatar_path']); ?>" alt="User Avatar" class="w-10 h-10 rounded-full object-cover mr-3">
                <span class="font-semibold"><?php echo htmlspecialchars($sidebar_user['username']); ?></span>
            </a>
            <a href="logout.php" class="flex items-center w-full mt-2 text-center py-2.5 px-4 rounded transition duration-200 bg-red-600 hover:bg-red-700">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                Log Out
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-10">
        <h1 class="text-3xl font-bold mb-6">My Billing History</h1>
        <div class="bg-white p-8 rounded-lg shadow-lg">
            <table class="min-w-full bg-white">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Invoice ID</th>
                        <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Seat</th>
                        <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Period</th>
                        <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Amount</th>
                        <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Actions</th>
                    </tr>
                </thead>
                <tbody class="text-gray-700">
                    <?php if($payment_slips_result->num_rows > 0): ?>
                        <?php while($slip = $payment_slips_result->fetch_assoc()): ?>
                            <tr>
                                <td class="text-left py-3 px-4">#<?php echo htmlspecialchars($slip['id']); ?></td>
                                <td class="text-left py-3 px-4"><?php echo htmlspecialchars($slip['seat_number']); ?></td>
                                <?php
                                // UI FIX: Check for invalid date before displaying to prevent errors.
                                if ($slip['date_of_joining'] && $slip['date_of_joining'] != '0000-00-00'):
                                ?>
                                    <td class="text-left py-3 px-4"><?php echo htmlspecialchars($slip['date_of_joining']) . " to " . htmlspecialchars($slip['date_of_leaving']); ?></td>
                                    <td class="text-left py-3 px-4">₹<?php echo htmlspecialchars(number_format($slip['amount_due'], 2)); ?></td>
                                <?php else: ?>
                                    <td class="text-left py-3 px-4 text-red-500 font-medium">Invalid Period</td>
                                    <td class="text-left py-3 px-4 text-red-500 font-medium">Calculation Error</td>
                                <?php endif; ?>
                                <td class="text-left py-3 px-4">
                                    <a href="view_slip.php?id=<?php echo $slip['id']; ?>" target="_blank" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-xs">View Slip</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-gray-500">You have no payment history.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
