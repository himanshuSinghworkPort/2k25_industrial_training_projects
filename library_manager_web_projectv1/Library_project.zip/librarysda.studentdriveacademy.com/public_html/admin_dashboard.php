<?php
// admin_dashboard.php

session_start();
require_once "db_connect.php";

// Security check for admin role
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin'){
    header("location: index.php");
    exit;
}

// Get the currently active session
$active_session_query = $conn->query("SELECT id, session_name FROM sessions WHERE is_active = 1 LIMIT 1");
$active_session = $active_session_query->fetch_assoc();
$active_session_id = $active_session['id'] ?? null;
$active_session_name = $active_session['session_name'] ?? 'None';

// ---- PAYMENT SLIP GENERATION FUNCTION ----
function generatePaymentSlip($conn, $seat_id) {
    // Get booking details
    $sql = "SELECT user_id, session_id, seat_number, date_of_joining, date_of_leaving FROM seats WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $seat_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $booking = $result->fetch_assoc();
    $stmt->close();

    // Only proceed if dates are valid
    if ($booking && $booking['date_of_joining'] && $booking['date_of_joining'] != '0000-00-00' && $booking['date_of_leaving']) {
        $date_joining = new DateTime($booking['date_of_joining']);
        $date_leaving = new DateTime($booking['date_of_leaving']);
        $duration = $date_joining->diff($date_leaving)->days + 1;

        // Fee calculation logic
        $amount_due = 500.00; // Base fee
        if ($duration > 10) {
            $extra_days = $duration - 10;
            $amount_due += $extra_days * 20.00;
        }

        // Insert into payments table
        $insert_sql = "INSERT INTO payments (user_id, seat_id, session_id, seat_number, date_of_joining, date_of_leaving, duration_days, amount_due) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("iiissssd", $booking['user_id'], $seat_id, $booking['session_id'], $booking['seat_number'], $booking['date_of_joining'], $booking['date_of_leaving'], $duration, $amount_due);
        $insert_stmt->execute();
        $insert_stmt->close();
    }
}

// ---- FORM HANDLING LOGIC ----
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_page = $_POST['current_page'] ?? 'overview';
    
    // Logic to APPROVE a seat request
    if (isset($_POST['approve_seat'])) {
        $seat_id = $_POST['seat_id'];
        $user_id = $_POST['user_id'];
        $today = date("Y-m-d");
        $sql = "UPDATE seats SET status = 'booked', user_id = ?, requested_by_id = NULL, date_of_joining = ? WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("iis", $user_id, $today, $seat_id);
            $stmt->execute();
            $stmt->close();
        }
    }
    
    // Logic for ADMIN to CANCEL a booking
    if (isset($_POST['admin_cancel_booking'])) {
        $seat_id = $_POST['seat_id'];
        $today = date("Y-m-d");
        
        $sql_set_leave = "UPDATE seats SET date_of_leaving = ? WHERE id = ?";
        if ($stmt = $conn->prepare($sql_set_leave)) {
            $stmt->bind_param("si", $today, $seat_id);
            $stmt->execute();
            $stmt->close();
            generatePaymentSlip($conn, $seat_id);
        }
        
        $sql_free_seat = "UPDATE seats SET status = 'available', user_id = NULL, requested_by_id = NULL, date_of_joining = NULL, date_of_leaving = NULL WHERE id = ?";
        if ($stmt = $conn->prepare($sql_free_seat)) {
            $stmt->bind_param("i", $seat_id);
            $stmt->execute();
            $stmt->close();
        }
    }

    // Logic to Clear All Bills
    if (isset($_POST['clear_all_bills'])) {
        $conn->query("TRUNCATE TABLE payments");
    }

    // Other POST logic
    if (isset($_POST['create_session'])) {
        $session_name = trim($_POST['session_name']);
        if (!empty($session_name)) {
            $conn->prepare("INSERT INTO sessions (session_name) VALUES (?)")->execute([$session_name]);
        }
    }
    if (isset($_POST['activate_session'])) {
        $session_to_activate = $_POST['session_id'];
        $conn->query("UPDATE sessions SET is_active = 0");
        $conn->prepare("UPDATE sessions SET is_active = 1 WHERE id = ?")->execute([$session_to_activate]);
    }
    if (isset($_POST['generate_seats'])) {
        if ($active_session_id) {
            $rows = intval($_POST['rows']);
            $cols = intval($_POST['cols']);
            $conn->prepare("DELETE FROM seats WHERE session_id = ?")->execute([$active_session_id]);
            $stmt = $conn->prepare("INSERT INTO seats (seat_number, session_id) VALUES (?, ?)");
            for ($r = 0; $r < $rows; $r++) {
                for ($c = 1; $c <= $cols; $c++) {
                    $seat_number = chr(65 + $r) . $c;
                    $stmt->bind_param("si", $seat_number, $active_session_id);
                    $stmt->execute();
                }
            }
            $stmt->close();
        }
    }
    if (isset($_POST['deny_seat'])) {
        $conn->prepare("UPDATE seats SET status = 'available', requested_by_id = NULL WHERE id = ?")->execute([$_POST['seat_id']]);
    }
    if (isset($_POST['toggle_reserved'])) {
        $new_status = ($_POST['current_status'] == 'available') ? 'reserved' : 'available';
        $conn->prepare("UPDATE seats SET status = ?, user_id = NULL, requested_by_id = NULL WHERE id = ?")->execute([$new_status, $_POST['seat_id']]);
    }
    if (isset($_POST['admin_book_seat'])) {
        if (!empty($_POST['user_id_to_book'])) {
            $today = date("Y-m-d");
            $conn->prepare("UPDATE seats SET status = 'booked', user_id = ?, requested_by_id = NULL, date_of_joining = ? WHERE id = ?")->execute([$_POST['user_id_to_book'], $today, $_POST['seat_id']]);
        }
    }

    header("location: admin_dashboard.php?page=" . $current_page);
    exit;
}


// Determine which page to display
$page = isset($_GET['page']) ? $_GET['page'] : 'overview';

// --- DATA FETCHING FOR VIEWS ---
$all_seats_result = null;
$stats = ['total' => 0, 'booked' => 0, 'available' => 0, 'requested' => 0];
if ($active_session_id) {
    $stats['total'] = $conn->query("SELECT COUNT(*) FROM seats WHERE session_id = $active_session_id")->fetch_row()[0];
    $stats['booked'] = $conn->query("SELECT COUNT(*) FROM seats WHERE session_id = $active_session_id AND status = 'booked'")->fetch_row()[0];
    $stats['available'] = $conn->query("SELECT COUNT(*) FROM seats WHERE session_id = $active_session_id AND status = 'available'")->fetch_row()[0];
    $stats['requested'] = $conn->query("SELECT COUNT(*) FROM seats WHERE session_id = $active_session_id AND status = 'requested'")->fetch_row()[0];

    $all_seats_sql = "SELECT s.id, s.seat_number, s.status, s.requested_by_id, s.date_of_joining, u_booked.username AS booked_by_username, u_requested.username AS requested_by_username FROM seats s LEFT JOIN users u_booked ON s.user_id = u_booked.id LEFT JOIN users u_requested ON s.requested_by_id = u_requested.id WHERE s.session_id = ? ORDER BY s.seat_number";
    $stmt_seats = $conn->prepare($all_seats_sql);
    $stmt_seats->bind_param("i", $active_session_id);
    $stmt_seats->execute();
    $all_seats_result = $stmt_seats->get_result();
}

$all_users_sql = "SELECT id, username FROM users WHERE role = 'user' ORDER BY username";
$all_users_result = $conn->query($all_users_sql);
$users_list = $all_users_result->fetch_all(MYSQLI_ASSOC);
$user_management_result = $conn->query("SELECT id, username, full_name, email, role FROM users ORDER BY username");
$all_sessions_result = $conn->query("SELECT id, session_name, is_active FROM sessions ORDER BY session_name DESC");
$payment_slips_result = $conn->query("SELECT p.*, u.username FROM payments p JOIN users u ON p.user_id = u.id ORDER BY p.generated_at DESC");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .seat { width: 70px; height: 70px; display: flex; flex-direction: column; align-items: center; justify-content: center; font-weight: bold; border-radius: 8px; transition: all 0.2s ease-in-out; border: 2px solid transparent; position: relative; }
        .seat-number { font-size: 1.1rem; }
        .user-name { font-size: 0.7rem; font-weight: normal; margin-top: 2px; }
        .seat.seat-available { background-color: #10B981; color: white; }
        .seat.seat-requested { background-color: #F59E0B; color: white; }
        .seat.seat-booked { background-color: #EF4444; color: white; }
        .seat.seat-reserved { background-color: #6B7280; color: white; }
    </style>
</head>
<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <aside class="w-64 bg-gray-800 text-white min-h-screen p-4 flex flex-col">
        <h2 class="text-2xl font-bold mb-10 text-center">SV Library Admin</h2>
        <nav class="flex-grow">
            <a href="admin_dashboard.php?page=overview" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php if($page == 'overview') echo 'bg-gray-700'; ?>">Seat Overview</a>
            <a href="admin_dashboard.php?page=seat_management" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php if($page == 'seat_management') echo 'bg-gray-700'; ?>">Seat Management</a>
            <a href="admin_dashboard.php?page=user_management" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php if($page == 'user_management') echo 'bg-gray-700'; ?>">User Management</a>
            <a href="admin_dashboard.php?page=billing" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php if($page == 'billing') echo 'bg-gray-700'; ?>">Billing</a>
            <a href="admin_dashboard.php?page=sessions" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php if($page == 'sessions') echo 'bg-gray-700'; ?>">Sessions</a>
            <a href="admin_dashboard.php?page=configuration" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php if($page == 'configuration') echo 'bg-gray-700'; ?>">Configuration</a>
        </nav>
        <div class="mt-auto">
             <a href="logout.php" class="block text-center py-2.5 px-4 rounded transition duration-200 bg-red-600 hover:bg-red-700">Log Out</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-10">
        <div class="bg-blue-100 text-blue-800 p-3 rounded-lg mb-6 text-center font-semibold">
            Currently Managing Session: <?php echo htmlspecialchars($active_session_name); ?>
        </div>
        <div class="bg-white p-8 rounded-lg shadow-lg">

            <?php if ($page === 'overview'): ?>
                <h1 class="text-3xl font-bold mb-6">Seat Overview</h1>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div class="bg-blue-100 p-6 rounded-lg">
                        <h3 class="text-lg font-medium text-blue-800">Total Seats</h3>
                        <p class="text-4xl font-bold text-blue-900 mt-2"><?php echo $stats['total']; ?></p>
                    </div>
                    <div class="bg-red-100 p-6 rounded-lg">
                        <h3 class="text-lg font-medium text-red-800">Booked Seats</h3>
                        <p class="text-4xl font-bold text-red-900 mt-2"><?php echo $stats['booked']; ?></p>
                    </div>
                    <div class="bg-green-100 p-6 rounded-lg">
                        <h3 class="text-lg font-medium text-green-800">Available Seats</h3>
                        <p class="text-4xl font-bold text-green-900 mt-2"><?php echo $stats['available']; ?></p>
                    </div>
                    <div class="bg-amber-100 p-6 rounded-lg">
                        <h3 class="text-lg font-medium text-amber-800">Pending Requests</h3>
                        <p class="text-4xl font-bold text-amber-900 mt-2"><?php echo $stats['requested']; ?></p>
                    </div>
                </div>
                <div class="border-t pt-6">
                    <div class="flex flex-wrap gap-4 mb-8">
                        <div class="flex items-center gap-2"><div class="w-5 h-5 rounded bg-green-500"></div><span>Available</span></div>
                        <div class="flex items-center gap-2"><div class="w-5 h-5 rounded bg-amber-500"></div><span>Requested</span></div>
                        <div class="flex items-center gap-2"><div class="w-5 h-5 rounded bg-red-500"></div><span>Booked</span></div>
                        <div class="flex items-center gap-2"><div class="w-5 h-5 rounded bg-gray-500"></div><span>Reserved</span></div>
                    </div>
                    <div class="grid grid-cols-5 gap-4">
                        <?php if ($all_seats_result): mysqli_data_seek($all_seats_result, 0); ?>
                        <?php while($seat = $all_seats_result->fetch_assoc()): ?>
                            <div class="seat seat-<?php echo $seat['status']; ?>">
                                <span class="seat-number"><?php echo htmlspecialchars($seat['seat_number']); ?></span>
                                <?php if($seat['status'] == 'booked' && !empty($seat['booked_by_username'])): ?>
                                    <span class="user-name"><?php echo htmlspecialchars($seat['booked_by_username']); ?></span>
                                <?php elseif($seat['status'] == 'requested' && !empty($seat['requested_by_username'])): ?>
                                    <span class="user-name"><?php echo htmlspecialchars($seat['requested_by_username']); ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($page === 'seat_management'): ?>
                <h1 class="text-3xl font-bold mb-6">Manage All Seats</h1>
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Seat</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Status / User</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Enrollment Date</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php if ($all_seats_result): mysqli_data_seek($all_seats_result, 0); ?>
                        <?php while($seat = $all_seats_result->fetch_assoc()): ?>
                            <tr>
                                <td class="text-left py-3 px-4"><?php echo htmlspecialchars($seat['seat_number']); ?></td>
                                <td class="text-left py-3 px-4">
                                    <span class="px-2 py-1 font-semibold leading-tight text-xs rounded-full <?php 
                                        switch($seat['status']) {
                                            case 'available': echo 'bg-green-100 text-green-700'; break;
                                            case 'requested': echo 'bg-amber-100 text-amber-700'; break;
                                            case 'booked': echo 'bg-red-100 text-red-700'; break;
                                            case 'reserved': echo 'bg-gray-200 text-gray-800'; break;
                                        }
                                    ?>">
                                        <?php echo ucfirst($seat['status']); ?>
                                    </span>
                                    <?php if($seat['status'] == 'booked' && !empty($seat['booked_by_username'])): ?>
                                        <span class="text-sm ml-2 text-gray-600">by <?php echo htmlspecialchars($seat['booked_by_username']); ?></span>
                                    <?php elseif($seat['status'] == 'requested' && !empty($seat['requested_by_username'])): ?>
                                        <span class="text-sm ml-2 text-gray-600">by <?php echo htmlspecialchars($seat['requested_by_username']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-left py-3 px-4 text-sm">
                                    <?php echo ($seat['date_of_joining'] && $seat['date_of_joining'] != '0000-00-00') ? htmlspecialchars($seat['date_of_joining']) : 'N/A'; ?>
                                </td>
                                <td class="text-left py-3 px-4">
                                    <div class="flex items-center gap-2">
                                        <?php if ($seat['status'] == 'available'): ?>
                                            <form method="post" action="admin_dashboard.php" class="flex items-center gap-2">
                                                <input type="hidden" name="current_page" value="seat_management">
                                                <input type="hidden" name="seat_id" value="<?php echo $seat['id']; ?>">
                                                <select name="user_id_to_book" class="text-xs border border-gray-300 rounded">
                                                    <option value="">Book for...</option>
                                                    <?php foreach($users_list as $user): ?>
                                                        <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <button type="submit" name="admin_book_seat" class="bg-green-500 hover:bg-green-600 text-white font-bold py-1 px-2 rounded text-xs">Book</button>
                                            </form>
                                            <form method="post" action="admin_dashboard.php">
                                                <input type="hidden" name="current_page" value="seat_management">
                                                <input type="hidden" name="seat_id" value="<?php echo $seat['id']; ?>">
                                                <input type="hidden" name="current_status" value="available">
                                                <button type="submit" name="toggle_reserved" class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-1 px-2 rounded text-xs">Reserve</button>
                                            </form>
                                        <?php elseif ($seat['status'] == 'reserved'): ?>
                                            <form method="post" action="admin_dashboard.php">
                                                <input type="hidden" name="current_page" value="seat_management">
                                                <input type="hidden" name="seat_id" value="<?php echo $seat['id']; ?>">
                                                <input type="hidden" name="current_status" value="reserved">
                                                <button type="submit" name="toggle_reserved" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-xs">Make Available</button>
                                            </form>
                                        <?php elseif ($seat['status'] == 'booked'): ?>
                                            <form method="post" action="admin_dashboard.php">
                                                <input type="hidden" name="current_page" value="seat_management">
                                                <input type="hidden" name="seat_id" value="<?php echo $seat['id']; ?>">
                                                <button type="submit" name="admin_cancel_booking" class="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded text-xs">Cancel & Bill</button>
                                            </form>
                                        <?php elseif ($seat['status'] == 'requested'): ?>
                                            <form method="post" action="admin_dashboard.php" class="inline-block">
                                                <input type="hidden" name="current_page" value="seat_management">
                                                <input type="hidden" name="seat_id" value="<?php echo $seat['id']; ?>">
                                                <input type="hidden" name="user_id" value="<?php echo $seat['requested_by_id']; ?>">
                                                <button type="submit" name="approve_seat" class="bg-green-500 hover:bg-green-600 text-white font-bold py-1 px-3 rounded text-xs">Approve</button>
                                            </form>
                                            <form method="post" action="admin_dashboard.php" class="inline-block">
                                                <input type="hidden" name="current_page" value="seat_management">
                                                <input type="hidden" name="seat_id" value="<?php echo $seat['id']; ?>">
                                                <button type="submit" name="deny_seat" class="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded text-xs">Deny</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; endif; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <?php if ($page === 'user_management'): ?>
                <h1 class="text-3xl font-bold mb-6">Manage Users</h1>
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Username</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Full Name</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Email</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Role</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php while($user = $user_management_result->fetch_assoc()): ?>
                            <tr>
                                <td class="text-left py-3 px-4"><?php echo htmlspecialchars($user['username']); ?></td>
                                <td class="text-left py-3 px-4"><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td class="text-left py-3 px-4"><?php echo htmlspecialchars($user['email']); ?></td>
                                <td class="text-left py-3 px-4"><?php echo ucfirst(htmlspecialchars($user['role'])); ?></td>
                                <td class="text-left py-3 px-4">
                                    <a href="profile.php?id=<?php echo $user['id']; ?>" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-xs">Edit Profile</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <?php if ($page === 'billing'): ?>
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-3xl font-bold">Generated Payment Slips</h1>
                    <form method="post" action="admin_dashboard.php" onsubmit="return confirm('Are you sure you want to delete all payment history? This action cannot be undone.');">
                        <input type="hidden" name="current_page" value="billing">
                        <button type="submit" name="clear_all_bills" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg text-sm">
                            Clear All Bills
                        </button>
                    </form>
                </div>
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">User</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Seat</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Period</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Amount</th>
                            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php while($slip = $payment_slips_result->fetch_assoc()): ?>
                            <tr>
                                <td class="text-left py-3 px-4"><?php echo htmlspecialchars($slip['username']); ?></td>
                                <td class="text-left py-3 px-4"><?php echo htmlspecialchars($slip['seat_number']); ?></td>
                                <?php if ($slip['date_of_joining'] && $slip['date_of_joining'] != '0000-00-00'): ?>
                                    <td class="text-left py-3 px-4"><?php echo htmlspecialchars($slip['date_of_joining']) . " to " . htmlspecialchars($slip['date_of_leaving']); ?></td>
                                    <td class="text-left py-3 px-4">₹<?php echo htmlspecialchars(number_format($slip['amount_due'], 2)); ?></td>
                                <?php else: ?>
                                    <td class="text-left py-3 px-4 text-red-500 font-medium" colspan="2">Invalid Period - Calculation Error</td>
                                <?php endif; ?>
                                <td class="text-left py-3 px-4">
                                    <a href="view_slip.php?id=<?php echo $slip['id']; ?>" target="_blank" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-xs">View Slip</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <?php if ($page === 'sessions'): ?>
                <h1 class="text-3xl font-bold mb-6">Manage Sessions</h1>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <h2 class="text-xl font-bold mb-4">Create New Session</h2>
                        <form method="post" action="admin_dashboard.php">
                            <input type="hidden" name="current_page" value="sessions">
                            <label for="session_name" class="block text-sm font-medium text-gray-700">Session Name (e.g., 2026-2027)</label>
                            <input type="text" name="session_name" id="session_name" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm" required>
                            <button type="submit" name="create_session" class="mt-4 w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md">Create Session</button>
                        </form>
                    </div>
                    <div>
                        <h2 class="text-xl font-bold mb-4">Existing Sessions</h2>
                        <ul class="space-y-2">
                            <?php mysqli_data_seek($all_sessions_result, 0); ?>
                            <?php while($session = $all_sessions_result->fetch_assoc()): ?>
                                <li class="flex justify-between items-center p-3 rounded-lg <?php echo $session['is_active'] ? 'bg-green-100' : 'bg-gray-100'; ?>">
                                    <span class="font-medium <?php echo $session['is_active'] ? 'text-green-800' : 'text-gray-800'; ?>"><?php echo htmlspecialchars($session['session_name']); ?></span>
                                    <?php if(!$session['is_active']): ?>
                                        <form method="post" action="admin_dashboard.php">
                                            <input type="hidden" name="current_page" value="sessions">
                                            <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                            <button type="submit" name="activate_session" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-xs">Set Active</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-green-600 font-bold text-xs">ACTIVE</span>
                                    <?php endif; ?>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($page === 'configuration'): ?>
                <h1 class="text-3xl font-bold mb-6">Seat Configuration for Session: <?php echo htmlspecialchars($active_session_name); ?></h1>
                <p class="text-gray-600 mb-4">Use this to generate a new seat layout. This will delete all seats and bookings for the <span class="font-bold">current active session only</span>.</p>
                <form method="post" action="admin_dashboard.php" class="flex items-end gap-4 bg-gray-50 p-4 rounded-lg">
                    <input type="hidden" name="current_page" value="configuration">
                    <div>
                        <label for="rows" class="block text-sm font-medium text-gray-700">Rows</label>
                        <input type="number" name="rows" id="rows" value="5" min="1" max="26" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm">
                    </div>
                    <div>
                        <label for="cols" class="block text-sm font-medium text-gray-700">Columns</label>
                        <input type="number" name="cols" id="cols" value="5" min="1" max="20" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm">
                    </div>
                    <button type="submit" name="generate_seats" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md" onclick="return confirm('Are you sure? This will delete the current seat layout and all bookings for the active session.');">Generate Seats</button>
                </form>
            <?php endif; ?>

        </div>
    </main>
</body>
</html>
