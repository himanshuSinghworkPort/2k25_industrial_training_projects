<?php
// register.php

// Include the database connection file
require_once "db_connect.php";

// Define variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";

// Process form data when the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } else {
        // Prepare a select statement to check if username already exists
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $param_username);
            $param_username = trim($_POST["username"]);
            
            if ($stmt->execute()) {
                $stmt->store_result();
                
                if ($stmt->num_rows == 1) {
                    $username_err = "This username is already taken.";
                } else {
                    $username = trim($_POST["username"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            $stmt->close();
        }
    }
    
    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";     
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";     
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting into database
    if (empty($username_err) && empty($password_err) && empty($confirm_password_err)) {
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password, role, date_of_joining_library) VALUES (?, ?, 'user', CURDATE())";
         
        if ($stmt = $conn->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Redirect to login page after successful registration
                header("location: index.php");
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            $stmt->close();
        }
    }
    
    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - SV Library System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-900 flex items-center justify-center min-h-screen">

    <div class="bg-gray-800 p-8 rounded-2xl shadow-2xl w-full max-w-sm">
        
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-white">Create Account</h1>
            <p class="text-gray-400 mt-2">Join the SV Library System.</p>
        </div>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="mb-4">
                <label for="username" class="block text-gray-300 text-sm font-medium mb-2">Username</label>
                <input type="text" name="username" id="username" class="w-full px-4 py-3 bg-gray-700 border <?php echo (!empty($username_err)) ? 'border-red-500' : 'border-gray-600'; ?> rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500" value="<?php echo $username; ?>">
                <span class="text-red-500 text-xs mt-1"><?php echo $username_err; ?></span>
            </div>    
            <div class="mb-4">
                <label for="password" class="block text-gray-300 text-sm font-medium mb-2">Password</label>
                <input type="password" name="password" id="password" class="w-full px-4 py-3 bg-gray-700 border <?php echo (!empty($password_err)) ? 'border-red-500' : 'border-gray-600'; ?> rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500" value="<?php echo $password; ?>">
                <span class="text-red-500 text-xs mt-1"><?php echo $password_err; ?></span>
            </div>
            <div class="mb-6">
                <label for="confirm_password" class="block text-gray-300 text-sm font-medium mb-2">Confirm Password</label>
                <input type="password" name="confirm_password" id="confirm_password" class="w-full px-4 py-3 bg-gray-700 border <?php echo (!empty($confirm_password_err)) ? 'border-red-500' : 'border-gray-600'; ?> rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500" value="<?php echo $confirm_password; ?>">
                <span class="text-red-500 text-xs mt-1"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="mb-6">
                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline transition duration-200 transform hover:scale-105">Sign Up</button>
            </div>
            <div class="text-center">
                <p class="text-sm text-gray-400">Already have an account? <a href="index.php" class="text-indigo-400 hover:text-indigo-300">Log in</a>.</p>
            </div>
        </form>
    </div>

</body>
</html>
