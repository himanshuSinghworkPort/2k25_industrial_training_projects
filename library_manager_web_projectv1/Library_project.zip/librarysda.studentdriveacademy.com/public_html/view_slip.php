<?php
session_start();
require_once "db_connect.php";

// Check if a slip ID is provided in the URL
if (!isset($_GET['id'])) {
    die("No slip ID provided.");
}

$slip_id = $_GET['id'];

// Prepare and execute a query to get the payment slip details
$sql = "SELECT p.*, u.username, u.full_name, u.email 
        FROM payments p 
        JOIN users u ON p.user_id = u.id 
        WHERE p.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $slip_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if a slip was found
if ($result->num_rows !== 1) {
    die("Payment slip not found.");
}
$slip = $result->fetch_assoc();
$stmt->close();

// Security check: regular users can only view their own payment slips
if ($_SESSION['role'] === 'user' && $_SESSION['id'] != $slip['user_id']) {
    die("Access denied. You can only view your own billing information.");
}

// Fee calculation for detailed breakdown
$base_fee = 500.00;
$per_day_fee_after_10 = 20.00;
$additional_days = 0;
$additional_charge = 0.00;

// Only calculate if the duration is valid
if ($slip['duration_days'] > 0) {
    if ($slip['duration_days'] > 10) {
        $additional_days = $slip['duration_days'] - 10;
        $additional_charge = $additional_days * $per_day_fee_after_10;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Slip - #<?php echo $slip['id']; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style> 
        body { font-family: 'Inter', sans-serif; } 
        @media print {
            body { -webkit-print-color-adjust: exact; }
            .no-print { display: none; }
        }
    </style>
</head>
<body class="bg-gray-100 p-10">
    <div class="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-lg">
        <div class="flex justify-between items-center border-b pb-4 mb-6">
            <div>
                <h1 class="text-3xl font-bold text-gray-800">Payment Slip</h1>
                <p class="text-gray-500">Invoice #<?php echo htmlspecialchars($slip['id']); ?></p>
            </div>
            <div class="text-right">
                <h2 class="text-xl font-bold">SV Library System</h2>
                <p class="text-gray-600">Kanpur</p>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-8 mb-8">
            <div>
                <h3 class="text-lg font-semibold text-gray-800 mb-2">Billed To:</h3>
                <p><?php echo htmlspecialchars($slip['full_name'] ?: $slip['username']); ?></p>
                <p><?php echo htmlspecialchars($slip['email']); ?></p>
            </div>
            <div class="text-right">
                <p><span class="font-semibold">Date Generated:</span> <?php echo date("F j, Y", strtotime($slip['generated_at'])); ?></p>
            </div>
        </div>

        <!-- Check for invalid date from old records -->
        <?php if ($slip['date_of_joining'] && $slip['date_of_joining'] != '0000-00-00'): ?>
            <table class="w-full mb-8">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="text-left p-3 font-semibold text-gray-600">Description</th>
                        <th class="text-right p-3 font-semibold text-gray-600">Details</th>
                        <th class="text-right p-3 font-semibold text-gray-600">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="border-b">
                        <td class="p-3">Base Fee</td>
                        <td class="p-3 text-right text-sm text-gray-500">For first 10 days</td>
                        <td class="p-3 text-right">₹<?php echo number_format($base_fee, 2); ?></td>
                    </tr>
                    <?php if ($additional_days > 0): ?>
                    <tr class="border-b">
                        <td class="p-3">Additional Days Charge</td>
                        <td class="p-3 text-right text-sm text-gray-500"><?php echo $additional_days; ?> days @ ₹<?php echo number_format($per_day_fee_after_10, 2); ?>/day</td>
                        <td class="p-3 text-right">₹<?php echo number_format($additional_charge, 2); ?></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td class="p-3 text-right font-bold text-xl" colspan="2">Total Due:</td>
                        <td class="p-3 text-right font-bold text-xl">₹<?php echo number_format($slip['amount_due'], 2); ?></td>
                    </tr>
                </tfoot>
            </table>
            <div class="text-sm text-gray-600 border-t pt-4">
                <p><span class="font-semibold">Seat:</span> <?php echo htmlspecialchars($slip['seat_number']); ?></p>
                <p><span class="font-semibold">Enrollment Date:</span> <?php echo date("F j, Y", strtotime($slip['date_of_joining'])); ?></p>
                <p><span class="font-semibold">Leaving Date:</span> <?php echo date("F j, Y", strtotime($slip['date_of_leaving'])); ?></p>
                <p><span class="font-semibold">Total Duration:</span> <?php echo htmlspecialchars($slip['duration_days']); ?> days</p>
            </div>
        <?php else: ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                <p class="font-bold">Billing Error</p>
                <p>This payment slip was generated from a booking with an invalid start date. Please contact an administrator.</p>
            </div>
        <?php endif; ?>
        
        <div class="text-center text-sm text-gray-500 mt-8 border-t pt-4">
            <p>Thank you for using SV Library System.</p>
            <button onclick="window.print()" class="no-print mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded">
                Print Slip
            </button>
        </div>
    </div>
</body>
</html>
