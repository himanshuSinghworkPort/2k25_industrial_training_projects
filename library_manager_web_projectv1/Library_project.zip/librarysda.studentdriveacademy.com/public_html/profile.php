<?php
// profile.php

session_start();
require_once "db_connect.php";

// Redirect to login if not logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: index.php");
    exit;
}

// Get user info for the sidebar (the logged-in user, not necessarily the profile being viewed)
$user_id_for_sidebar = $_SESSION['id'];
$sidebar_user_stmt = $conn->prepare("SELECT username, avatar_path FROM users WHERE id = ?");
$sidebar_user_stmt->bind_param("i", $user_id_for_sidebar);
$sidebar_user_stmt->execute();
$sidebar_user_result = $sidebar_user_stmt->get_result();
$sidebar_user = $sidebar_user_result->fetch_assoc();
$sidebar_user_stmt->close();


// Determine which user's profile to display
$profile_user_id = $_SESSION['id']; // Default to own profile
$is_admin_viewing = false;
if (isset($_GET['id']) && $_SESSION['role'] === 'admin') {
    $profile_user_id = $_GET['id'];
    $is_admin_viewing = true;
}

// ---- HANDLE FORM SUBMISSIONS ----
$update_success_msg = "";
$password_success_msg = "";
$password_err_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_user_id = $_SESSION['id'];
    $is_admin = $_SESSION['role'] === 'admin';
    $is_profile_owner = ($current_user_id == $profile_user_id);

    // --- Handle Profile Information Update ---
    if (isset($_POST['update_profile']) && ($is_admin || $is_profile_owner)) {
        $full_name = trim($_POST['full_name']);
        $guardian_name = trim($_POST['guardian_name']);
        $email = trim($_POST['email']);
        $phone_number = trim($_POST['phone_number']);
        $address = trim($_POST['address']);
        $date_of_birth = trim($_POST['date_of_birth']);
        // Admin can change the joining date, but users cannot
        $date_of_joining_library = $is_admin ? trim($_POST['date_of_joining_library']) : null;
        
        // Handle avatar upload
        if (isset($_FILES["avatar"]) && $_FILES["avatar"]["error"] == 0) {
            $target_dir = "uploads/avatars/";
            $file_extension = pathinfo($_FILES["avatar"]["name"], PATHINFO_EXTENSION);
            $target_file = $target_dir . "user_" . $profile_user_id . "." . $file_extension;
            $allowTypes = array('jpg','png','jpeg','gif');
            if (in_array(strtolower($file_extension), $allowTypes)) {
                if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $target_file)) {
                    $conn->prepare("UPDATE users SET avatar_path = ? WHERE id = ?")->execute([$target_file, $profile_user_id]);
                }
            }
        }

        // Update other profile info
        if ($is_admin) {
            $sql = "UPDATE users SET full_name = ?, guardian_name = ?, email = ?, phone_number = ?, address = ?, date_of_birth = ?, date_of_joining_library = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssssi", $full_name, $guardian_name, $email, $phone_number, $address, $date_of_birth, $date_of_joining_library, $profile_user_id);
        } else {
            $sql = "UPDATE users SET full_name = ?, guardian_name = ?, email = ?, phone_number = ?, address = ?, date_of_birth = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssi", $full_name, $guardian_name, $email, $phone_number, $address, $date_of_birth, $profile_user_id);
        }
        
        if($stmt->execute()){
            $update_success_msg = "Profile updated successfully!";
        }
        $stmt->close();
    }

    // --- Handle Password Change (Admin only) ---
    if (isset($_POST['change_password']) && $is_admin) {
        $new_password = $_POST['new_password'];
        if (strlen($new_password) < 6) {
            $password_err_msg = "Password must be at least 6 characters long.";
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET password = ? WHERE id = ?";
            if($stmt = $conn->prepare($sql)){
                $stmt->bind_param("si", $hashed_password, $profile_user_id);
                if($stmt->execute()){
                    $password_success_msg = "Password changed successfully!";
                }
                $stmt->close();
            }
        }
    }
}


// Fetch the user's data for display
$sql = "SELECT username, full_name, guardian_name, email, phone_number, address, avatar_path, role, date_of_birth, date_of_joining_library FROM users WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $profile_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
    } else {
        header("location: user_dashboard.php");
        exit;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - SV Library System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <aside class="w-64 bg-gray-800 text-white min-h-screen p-4 flex flex-col justify-between">
        <div>
            <div class="flex items-center justify-center mb-10">
                 <svg class="w-8 h-8 mr-2 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"></path></svg>
                <h2 class="text-2xl font-bold">SV Library</h2>
            </div>
            <nav>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <a href="admin_dashboard.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 hover:text-white">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                        Admin Dashboard
                    </a>
                <?php else: ?>
                    <a href="user_dashboard.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 hover:text-white">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h12a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V6z"></path></svg>
                        Book a Seat
                    </a>
                    <a href="billing.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 hover:text-white">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path></svg>
                        My Billing
                    </a>
                <?php endif; ?>
                <a href="profile.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 bg-gray-700 text-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                    My Profile
                </a>
            </nav>
        </div>
        <div>
            <div class="border-t border-gray-700 mb-4"></div>
            <a href="profile.php" class="flex items-center p-2 rounded transition duration-200 hover:bg-gray-700">
                <img src="<?php echo htmlspecialchars($sidebar_user['avatar_path']); ?>" alt="User Avatar" class="w-10 h-10 rounded-full object-cover mr-3">
                <span class="font-semibold"><?php echo htmlspecialchars($sidebar_user['username']); ?></span>
            </a>
            <a href="logout.php" class="flex items-center w-full mt-2 text-center py-2.5 px-4 rounded transition duration-200 bg-red-600 hover:bg-red-700">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                Log Out
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-10">
        <h1 class="text-3xl font-bold mb-6">User Profile</h1>

        <?php if(!empty($update_success_msg)): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                <p><?php echo $update_success_msg; ?></p>
            </div>
        <?php endif; ?>

        <div class="bg-white p-8 rounded-lg shadow-lg">
            <form action="profile.php<?php if($is_admin_viewing) echo '?id='.$profile_user_id; ?>" method="post" enctype="multipart/form-data">
                <div class="flex items-start space-x-8">
                    <!-- Avatar Section -->
                    <div class="flex flex-col items-center">
                        <img src="<?php echo htmlspecialchars($user['avatar_path']); ?>" alt="Profile Avatar" class="w-32 h-32 rounded-full object-cover border-4 border-gray-200 mb-4">
                        <label for="avatar" class="cursor-pointer bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded text-sm">
                            Change Avatar
                            <input type="file" name="avatar" id="avatar" class="hidden">
                        </label>
                    </div>

                    <!-- Profile Details Section -->
                    <div class="flex-1 grid grid-cols-2 gap-6">
                        <div>
                            <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                            <input type="text" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" class="mt-1 block w-full bg-gray-100 px-3 py-2 border border-gray-300 rounded-md shadow-sm" readonly>
                        </div>
                        <div>
                            <label for="role" class="block text-sm font-medium text-gray-700">Role</label>
                            <input type="text" id="role" value="<?php echo ucfirst(htmlspecialchars($user['role'])); ?>" class="mt-1 block w-full bg-gray-100 px-3 py-2 border border-gray-300 rounded-md shadow-sm" readonly>
                        </div>
                        <div>
                            <label for="full_name" class="block text-sm font-medium text-gray-700">Full Name</label>
                            <input type="text" name="full_name" id="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="guardian_name" class="block text-sm font-medium text-gray-700">Guardian's Name</label>
                            <input type="text" name="guardian_name" id="guardian_name" value="<?php echo htmlspecialchars($user['guardian_name']); ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                            <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="phone_number" class="block text-sm font-medium text-gray-700">Phone Number</label>
                            <input type="text" name="phone_number" id="phone_number" value="<?php echo htmlspecialchars($user['phone_number']); ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500">
                        </div>
                         <div>
                            <label for="date_of_birth" class="block text-sm font-medium text-gray-700">Date of Birth</label>
                            <input type="date" name="date_of_birth" id="date_of_birth" value="<?php echo htmlspecialchars($user['date_of_birth']); ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="date_of_joining_library" class="block text-sm font-medium text-gray-700">Date of Joining</label>
                            <input type="date" name="date_of_joining_library" id="date_of_joining_library" value="<?php echo htmlspecialchars($user['date_of_joining_library']); ?>" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 <?php if(!$is_admin_viewing) echo 'bg-gray-100'; ?>" <?php if(!$is_admin_viewing) echo 'readonly'; ?>>
                        </div>
                        <div class="col-span-2">
                            <label for="address" class="block text-sm font-medium text-gray-700">Address</label>
                            <textarea name="address" id="address" rows="2" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500"><?php echo htmlspecialchars($user['address']); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="mt-6 text-right">
                    <button type="submit" name="update_profile" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-lg">Save Changes</button>
                </div>
            </form>
        </div>

        <!-- Admin-only Password Change Section -->
        <?php if ($is_admin_viewing): ?>
        <div class="bg-white p-8 rounded-lg shadow-lg mt-8">
            <h2 class="text-xl font-bold mb-4">Change User's Password</h2>
            <?php if(!empty($password_success_msg)): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                <p><?php echo $password_success_msg; ?></p>
            </div>
            <?php endif; ?>
            <?php if(!empty($password_err_msg)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                <p><?php echo $password_err_msg; ?></p>
            </div>
            <?php endif; ?>
            <form action="profile.php?id=<?php echo $profile_user_id; ?>" method="post">
                <div class="flex items-end gap-4">
                    <div class="flex-1">
                        <label for="new_password" class="block text-sm font-medium text-gray-700">New Password</label>
                        <input type="password" name="new_password" id="new_password" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500">
                    </div>
                    <button type="submit" name="change_password" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg">Change Password</button>
                </div>
            </form>
        </div>
        <?php endif; ?>

    </main>
</body>
</html>
