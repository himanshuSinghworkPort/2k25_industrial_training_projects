<?php
// index.php (formerly login.php)

// Start the session ONCE at the very top of the script.
session_start();

// If the user is already logged in, redirect them to their respective dashboard
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    if($_SESSION["role"] === 'admin'){
        header("location: admin_dashboard.php");
    } else {
        header("location: user_dashboard.php");
    }
    exit;
}

// Include the database connection file
require_once "db_connect.php";

// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";

// Process form data when the form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials if there are no input errors
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password, role FROM users WHERE username = ?";
        
        if($stmt = $conn->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Store result
                $stmt->store_result();
                
                // Check if username exists, if yes then verify password
                if($stmt->num_rows == 1){                    
                    // Bind result variables
                    $stmt->bind_result($id, $username, $hashed_password, $role);
                    if($stmt->fetch()){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct. Session is already started.
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;
                            $_SESSION["role"] = $role;                            
                            
                            // Redirect user based on their role
                            if($role === 'admin'){
                                header("location: admin_dashboard.php");
                            } else {
                                header("location: user_dashboard.php");
                            }
                        } else{
                            // Password is not valid
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }
    
    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SV Library System</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-900 flex flex-col items-center justify-center min-h-screen">

    <div class="bg-gray-800 p-8 rounded-2xl shadow-2xl w-full max-w-sm">
        
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-white">Welcome to SV Library System</h1>
            <p class="text-gray-400 mt-2">Please enter your credentials to log in.</p>
        </div>

        <?php 
        // Display login error if it exists
        if(!empty($login_err)){
            echo '<div class="bg-red-500 text-white text-center p-3 rounded-lg mb-4">' . $login_err . '</div>';
        }        
        ?>

        <!-- The form action is set to the current file (index.php) -->
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            
            <div class="mb-4">
                <label for="username" class="block text-gray-300 text-sm font-medium mb-2">Username</label>
                <input type="text" id="username" name="username" class="w-full px-4 py-3 bg-gray-700 border <?php echo (!empty($username_err)) ? 'border-red-500' : 'border-gray-600'; ?> rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500" value="<?php echo $username; ?>" placeholder="e.g., admin">
                <span class="text-red-500 text-xs mt-1"><?php echo $username_err; ?></span>
            </div>

            <div class="mb-6">
                <label for="password" class="block text-gray-300 text-sm font-medium mb-2">Password</label>
                <input type="password" id="password" name="password" class="w-full px-4 py-3 bg-gray-700 border <?php echo (!empty($password_err)) ? 'border-red-500' : 'border-gray-600'; ?> rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="••••••••">
                <span class="text-red-500 text-xs mt-1"><?php echo $password_err; ?></span>
            </div>

            <div class="mb-6">
                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline transition duration-200 transform hover:scale-105">
                    Log In
                </button>
            </div>
            
            <!-- Link to registration page -->
            <div class="text-center">
                <p class="text-sm text-gray-400">Don't have an account? <a href="register.php" class="text-indigo-400 hover:text-indigo-300">Sign up now</a>.</p>
            </div>
        </form>
    </div>

    <!-- Footer -->
    <footer class="text-center text-gray-500 text-xs mt-8">
        <p>Developed by Himanshu Singh (Student Drive Academy @SV Infotech, Kanpur)</p>
        <p class="mt-1">We provide software solutions and web frameworks.</p>
        <p class="mt-1">
            Mail us at <a href="mailto:himanshusingh1814@gmail.com" class="text-indigo-400 hover:underline">himanshusingh1814@gmail.com</a> | 
            Contact us at <a href="tel:8948324461" class="text-indigo-400 hover:underline">8948324461</a>
        </p>
    </footer>

</body>
</html>
