<?php
// generate_password_hash.php
// A simple tool to generate a secure password hash.

$generated_hash = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['password'])) {
        // Get the password from the form
        $password_to_hash = $_POST['password'];
        
        // Generate the hash using PHP's recommended standard
        $generated_hash = password_hash($password_to_hash, PASSWORD_DEFAULT);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Password Hash Generator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h1 class="text-2xl font-bold text-center mb-4">Password Hash Generator</h1>
        <p class="text-center text-gray-600 mb-6">Use this tool to create a secure hash for your user passwords. Enter a password below and click "Generate" to get the hash you can store in your database.</p>
        
        <form action="generate_password_hash.php" method="post">
            <div class="mb-4">
                <label for="password" class="block text-gray-700 font-medium mb-2">Password to Hash:</label>
                <input type="text" name="password" id="password" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
            </div>
            <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg">
                Generate Hash
            </button>
        </form>

        <?php if (!empty($generated_hash)): ?>
            <div class="mt-8 p-4 bg-green-100 border-l-4 border-green-500 rounded-r-lg">
                <h2 class="font-bold text-lg text-green-800">Generated Hash:</h2>
                <p class="text-sm text-gray-700 mt-2">Copy this entire string and paste it into the `password` column in your `users` table in phpMyAdmin.</p>
                <textarea readonly class="w-full mt-2 p-2 bg-gray-50 border rounded-lg text-gray-800" rows="3"><?php echo htmlspecialchars($generated_hash); ?></textarea>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>
