<?php
// db_connect.php
// This file contains the database connection configuration.

// Database credentials
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'YOUR_DB_SERVER_USERNAME'); // Your database username (default is 'root' for XAMPP)
define('DB_PASSWORD', 'YOUR_DB_SERVER_PASSWORD'); // Your database password (default is empty for XAMPP)
define('DB_NAME', 'YOUR_DB_NAME'); // The name of the database we created

// Attempt to connect to the MySQL database
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check the connection
if($conn === false){
    // If connection fails, stop the script and display an error.
    die("ERROR: Could not connect. " . $conn->connect_error);
}

// Note: It's good practice to close the connection when you're done with it,
// but for scripts that include this file and run to completion, PHP
// often handles this automatically. In long-running scripts,
// you would explicitly call $conn->close();
?>
