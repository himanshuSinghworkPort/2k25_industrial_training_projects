<?php
// user_dashboard.php

session_start();
require_once "db_connect.php";

// Security check
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}

// Get user info for the sidebar
$user_id_for_sidebar = $_SESSION['id'];
$sidebar_user_stmt = $conn->prepare("SELECT username, avatar_path FROM users WHERE id = ?");
$sidebar_user_stmt->bind_param("i", $user_id_for_sidebar);
$sidebar_user_stmt->execute();
$sidebar_user_result = $sidebar_user_stmt->get_result();
$sidebar_user = $sidebar_user_result->fetch_assoc();
$sidebar_user_stmt->close();


// Get the currently active session ID
$active_session_query = $conn->query("SELECT id FROM sessions WHERE is_active = 1 LIMIT 1");
$active_session_id = $active_session_query->fetch_assoc()['id'] ?? null;

// ---- SEAT BOOKING LOGIC ----
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_seat'])) {
    $seat_id = $_POST['seat_id'];
    $user_id = $_SESSION['id'];

    // Check if the seat is available in the active session
    $check_sql = "SELECT status FROM seats WHERE id = ? AND status = 'available' AND session_id = ?";
    if ($check_stmt = $conn->prepare($check_sql)) {
        $check_stmt->bind_param("ii", $seat_id, $active_session_id);
        $check_stmt->execute();
        $check_stmt->store_result();
        
        if ($check_stmt->num_rows == 1) {
            $update_sql = "UPDATE seats SET status = 'requested', requested_by_id = ? WHERE id = ?";
            if ($stmt = $conn->prepare($update_sql)) {
                $stmt->bind_param("ii", $user_id, $seat_id);
                $stmt->execute();
                $stmt->close();
            }
        }
        $check_stmt->close();
    }
    header("location: user_dashboard.php");
    exit;
}

// Fetch seats for the ACTIVE session only
$seats_result = null;
if($active_session_id) {
    $stmt = $conn->prepare("SELECT id, seat_number, status, requested_by_id, user_id FROM seats WHERE session_id = ? ORDER BY seat_number");
    $stmt->bind_param("i", $active_session_id);
    $stmt->execute();
    $seats_result = $stmt->get_result();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - SV Library System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .seat { width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; font-weight: bold; border-radius: 8px; cursor: pointer; transition: all 0.2s ease-in-out; border: 2px solid transparent; }
        .seat.seat-available { background-color: #10B981; color: white; }
        .seat.seat-available:hover { background-color: #059669; transform: scale(1.05); }
        .seat.seat-requested { background-color: #F59E0B; color: white; cursor: not-allowed; }
        .seat.seat-booked { background-color: #EF4444; color: white; cursor: not-allowed; }
        .seat.seat-reserved { background-color: #6B7280; color: white; cursor: not-allowed; }
        .seat-mine-requested { border: 3px solid #3B82F6; }
        .seat-mine-booked { border: 3px solid #8B5CF6; }
    </style>
</head>
<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <aside class="w-64 bg-gray-800 text-white min-h-screen p-4 flex flex-col justify-between">
        <div>
            <div class="flex items-center justify-center mb-10">
                 <svg class="w-8 h-8 mr-2 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v11.494m-9-5.747h18"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"></path></svg>
                <h2 class="text-2xl font-bold">SV Library</h2>
            </div>
            <nav>
                <a href="user_dashboard.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 bg-gray-700 text-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h12a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V6z"></path></svg>
                    Book a Seat
                </a>
                <a href="profile.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 hover:text-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                    My Profile
                </a>
                <a href="billing.php" class="flex items-center py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 hover:text-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path></svg>
                    My Billing
                </a>
            </nav>
        </div>
        <div>
            <div class="border-t border-gray-700 mb-4"></div>
            <a href="profile.php" class="flex items-center p-2 rounded transition duration-200 hover:bg-gray-700">
                <img src="<?php echo htmlspecialchars($sidebar_user['avatar_path']); ?>" alt="User Avatar" class="w-10 h-10 rounded-full object-cover mr-3">
                <span class="font-semibold"><?php echo htmlspecialchars($sidebar_user['username']); ?></span>
            </a>
            <a href="logout.php" class="flex items-center w-full mt-2 text-center py-2.5 px-4 rounded transition duration-200 bg-red-600 hover:bg-red-700">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                Log Out
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-10 flex flex-col">
        <div>
            <h1 class="text-3xl font-bold mb-2">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h1>
            
            <div class="bg-white p-8 rounded-lg shadow-lg mt-6">
                <h2 class="text-2xl font-bold mb-6">Library Seat Map</h2>
                <p class="text-gray-600 mb-6">Click on an available green seat to request a booking. The admin will approve your request.</p>
                
                <div class="flex flex-wrap gap-4 mb-8">
                    <div class="flex items-center gap-2"><div class="w-5 h-5 rounded bg-green-500"></div><span>Available</span></div>
                    <div class="flex items-center gap-2"><div class="w-5 h-5 rounded bg-amber-500"></div><span>Requested</span></div>
                    <div class="flex items-center gap-2"><div class="w-5 h-5 rounded bg-red-500"></div><span>Booked</span></div>
                    <div class="flex items-center gap-2"><div class="w-5 h-5 rounded bg-gray-500"></div><span>Reserved</span></div>
                    <div class="flex items-center gap-2"><div class="w-5 h-5 rounded border-2 border-blue-500"></div><span>Your Request</span></div>
                    <div class="flex items-center gap-2"><div class="w-5 h-5 rounded border-2 border-violet-500"></div><span>Your Booking</span></div>
                </div>

                <div class="grid grid-cols-5 gap-4">
                    <?php if($seats_result): while($seat = $seats_result->fetch_assoc()): ?>
                        <?php
                            $seat_class = 'seat-' . $seat['status'];
                            if ($seat['status'] == 'requested' && $seat['requested_by_id'] == $_SESSION['id']) {
                                $seat_class .= ' seat-mine-requested';
                            } elseif ($seat['status'] == 'booked' && $seat['user_id'] == $_SESSION['id']) {
                                $seat_class .= ' seat-mine-booked';
                            }
                        ?>
                        
                        <?php if ($seat['status'] == 'available'): ?>
                            <form method="post" action="user_dashboard.php">
                                <input type="hidden" name="seat_id" value="<?php echo $seat['id']; ?>">
                                <button type="submit" name="request_seat" class="seat <?php echo $seat_class; ?>">
                                    <?php echo htmlspecialchars($seat['seat_number']); ?>
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="seat <?php echo $seat_class; ?>">
                                <?php echo htmlspecialchars($seat['seat_number']); ?>
                            </div>
                        <?php endif; ?>

                    <?php endwhile; else: ?>
                        <p class="col-span-5 text-center text-gray-500">No seats have been configured for the active session.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <footer class="text-center text-gray-600 text-sm mt-auto pt-6">
            <p>Developed by Himanshu Singh (Student Drive Academy @SV Infotech, Kanpur)</p>
            <p class="mt-1">We provide software solutions and web frameworks.</p>
            <p class="mt-1">
                Mail us at <a href="mailto:himanshusingh1814@gmail.com" class="text-indigo-600 hover:underline">himanshusingh1814@gmail.com</a> | 
                Contact us at <a href="tel:8948324461" class="text-indigo-600 hover:underline">8948324461</a>
            </p>
        </footer>
    </main>

</body>
</html>
